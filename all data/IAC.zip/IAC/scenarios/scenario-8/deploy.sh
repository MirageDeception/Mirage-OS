#!/usr/bin/env bash
#
# deploy.sh — Deploy Deception Scenario 8 (Lambda Role Chaining — Compliance)
#
# Deploys a pivot role with access to compliance S3/SM/SSM data.
# The attacker discovers the PIVOT_ROLE_ARN in Lambda env vars and assumes it directly.
#
# Can either:
#   A) Link to Scenario 6 (adds PIVOT_ROLE_ARN to existing Lambda env vars)
#   B) Deploy standalone (creates its own Lambda + discovery role)
#
# Usage:
#   chmod +x deploy.sh
#   ./deploy.sh
#
set -euo pipefail

# ---------------------------------------------------------------
# Color helpers
# ---------------------------------------------------------------
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info()  { echo -e "${CYAN}[*]${NC} $*"; }
ok()    { echo -e "${GREEN}[+]${NC} $*"; }
warn()  { echo -e "${YELLOW}[!]${NC} $*"; }

# ---------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------
STACK_NAME="deception-scenario-8"
TEMPLATE_FILE="template.yaml"
REGION="${AWS_DEFAULT_REGION:-us-west-2}"

# ---------------------------------------------------------------
# Resolve the AWS Account ID
# ---------------------------------------------------------------
info "Resolving AWS Account ID..."
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
ok "Account ID: ${ACCOUNT_ID}"

# ---------------------------------------------------------------
# Check if Scenario 6 exists
# ---------------------------------------------------------------
SCENARIO6_EXISTS="false"
SCENARIO6_FUNCTION=$(aws cloudformation describe-stacks \
  --stack-name "deception-scenario-6" \
  --region "${REGION}" \
  --query "Stacks[0].Outputs[?OutputKey=='LambdaFunctionName'].OutputValue" \
  --output text 2>/dev/null || echo "")

if [ -n "${SCENARIO6_FUNCTION}" ] && [ "${SCENARIO6_FUNCTION}" != "None" ]; then
  SCENARIO6_EXISTS="true"
fi

# ---------------------------------------------------------------
# Ask: Link to Scenario 6 or standalone?
# ---------------------------------------------------------------
echo ""
echo -e "${CYAN}=============================================${NC}"
echo -e "${CYAN}  Scenario 8 — Lambda Role Chaining${NC}"
echo -e "${CYAN}  (Compliance Pivot)${NC}"
echo -e "${CYAN}=============================================${NC}"
echo ""

LINK_TO_6="false"
if [ "${SCENARIO6_EXISTS}" = "true" ]; then
  echo -e "  ${GREEN}Scenario 6 detected:${NC} Lambda function '${SCENARIO6_FUNCTION}'"
  echo ""
  echo "  Options:"
  echo "    L) Link to Scenario 6 — adds PIVOT_ROLE_ARN to existing Lambda env vars"
  echo "       Attacker reads Scenario 6's Lambda config → finds pivot role → assumes it"
  echo "    S) Standalone — creates a separate compliance Lambda + discovery role"
  echo ""
  read -rp "  Link to Scenario 6 or Standalone? [L/s]: " LINK_CHOICE
  LINK_CHOICE=${LINK_CHOICE:-L}
  if [ "${LINK_CHOICE}" = "L" ] || [ "${LINK_CHOICE}" = "l" ]; then
    LINK_TO_6="true"
  fi
else
  warn "Scenario 6 not deployed. Deploying standalone."
  echo ""
fi

# ---------------------------------------------------------------
# Show cost estimate
# ---------------------------------------------------------------
echo ""
echo -e "${YELLOW}--- Cost Estimate ---${NC}"
echo "  Secrets Manager (1 secret):   \$0.40"
echo "  S3 (compliance reports):      \$0.00"
echo "  SSM Standard (2 params):      \$0.00"
echo "  IAM resources:                \$0.00"
if [ "${LINK_TO_6}" = "false" ]; then
  echo "  Lambda (standalone, never invoked): \$0.00"
fi
echo -e "  ${GREEN}Total: \$0.40/mo${NC}"
echo ""

read -rp "  Deploy? [Y/n]: " DEPLOY_CONFIRM
DEPLOY_CONFIRM=${DEPLOY_CONFIRM:-Y}
if [ "${DEPLOY_CONFIRM}" != "Y" ] && [ "${DEPLOY_CONFIRM}" != "y" ]; then
  echo "Aborted."
  exit 0
fi

# ---------------------------------------------------------------
# Deploy the CloudFormation stack
# ---------------------------------------------------------------
info "Deploying CloudFormation stack: ${STACK_NAME} ..."
aws cloudformation deploy \
  --template-file "${TEMPLATE_FILE}" \
  --stack-name "${STACK_NAME}" \
  --parameter-overrides \
      AccountId="${ACCOUNT_ID}" \
      LinkToScenario6="${LINK_TO_6}" \
  --capabilities CAPABILITY_NAMED_IAM \
  --region "${REGION}" \
  --no-fail-on-empty-changeset

ok "Stack deployed successfully."

# ---------------------------------------------------------------
# If linked, add PIVOT_ROLE_ARN to Scenario 6's Lambda env vars
# ---------------------------------------------------------------
if [ "${LINK_TO_6}" = "true" ]; then
  PIVOT_ROLE_ARN=$(aws cloudformation describe-stacks \
    --stack-name "${STACK_NAME}" \
    --region "${REGION}" \
    --query "Stacks[0].Outputs[?OutputKey=='PivotRoleArn'].OutputValue" \
    --output text)

  info "Adding PIVOT_ROLE_ARN to Scenario 6's Lambda env vars..."

  # Get current env vars
  CURRENT_ENV=$(aws lambda get-function-configuration \
    --function-name "${SCENARIO6_FUNCTION}" \
    --region "${REGION}" \
    --query "Environment.Variables" \
    --output json)

  # Add PIVOT_ROLE_ARN
  UPDATED_ENV=$(echo "${CURRENT_ENV}" | jq --arg arn "${PIVOT_ROLE_ARN}" '. + {"PIVOT_ROLE_ARN": $arn}')

  aws lambda update-function-configuration \
    --function-name "${SCENARIO6_FUNCTION}" \
    --environment "{\"Variables\": ${UPDATED_ENV}}" \
    --region "${REGION}" > /dev/null

  ok "PIVOT_ROLE_ARN added to ${SCENARIO6_FUNCTION} env vars"
  info "Attacker path: Assume scenario-6 role → read Lambda config → find PIVOT_ROLE_ARN → assume pivot role"
fi

# ---------------------------------------------------------------
# Seed data stores
# ---------------------------------------------------------------
info "Seeding compliance data stores..."

# Seed S3
BUCKET_NAME="compliance-audit-reports-${ACCOUNT_ID}"
if [ -f "fake-data/pci-dss-report.json" ]; then
  aws s3 cp fake-data/pci-dss-report.json "s3://${BUCKET_NAME}/reports/2024-Q4/pci-dss-assessment.json" --region "${REGION}"
fi
if [ -f "fake-data/sox-controls.json" ]; then
  aws s3 cp fake-data/sox-controls.json "s3://${BUCKET_NAME}/reports/2024-Q4/sox-controls-matrix.json" --region "${REGION}"
fi

# Seed Secrets Manager
if [ -f "fake-data/encryption-keys.json" ]; then
  aws secretsmanager put-secret-value \
    --secret-id "prod/compliance/encryption-keys" \
    --secret-string file://fake-data/encryption-keys.json \
    --region "${REGION}" 2>/dev/null || true
fi

# Seed SSM
if [ -f "fake-data/database-credentials.json" ]; then
  aws ssm put-parameter \
    --name "/prod/compliance/database-credentials" \
    --value file://fake-data/database-credentials.json \
    --type String --overwrite \
    --region "${REGION}" 2>/dev/null || true
fi
if [ -f "fake-data/third-party-integrations.json" ]; then
  aws ssm put-parameter \
    --name "/prod/compliance/third-party-integrations" \
    --value file://fake-data/third-party-integrations.json \
    --type String --overwrite \
    --region "${REGION}" 2>/dev/null || true
fi

ok "Data stores seeded."

# ---------------------------------------------------------------
# Summary
# ---------------------------------------------------------------
echo ""
echo -e "${GREEN}=============================================${NC}"
echo -e "${GREEN}  Deception Scenario 8 — Deployed${NC}"
echo -e "${GREEN}=============================================${NC}"
if [ "${LINK_TO_6}" = "true" ]; then
  echo "  Mode       : Linked to Scenario 6"
  echo "  Entry point: lambda-ops-readonly-role (from scenario-6)"
  echo "  Lambda     : ${SCENARIO6_FUNCTION} (PIVOT_ROLE_ARN added to env)"
else
  echo "  Mode       : Standalone"
  echo "  Entry point: compliance-audit-readonly-role"
  echo "  Lambda     : prod-compliance-report-generator"
fi
echo "  Pivot Role : prod-compliance-data-access-role"
echo "  S3         : ${BUCKET_NAME}"
echo "  Secret     : prod/compliance/encryption-keys"
echo "  SSM        : /prod/compliance/database-credentials"
echo "             : /prod/compliance/third-party-integrations"
echo "  Cost       : \$0.40/mo"
echo -e "${GREEN}=============================================${NC}"
echo ""
ok "Done. Run abuse.sh to simulate the attack."
