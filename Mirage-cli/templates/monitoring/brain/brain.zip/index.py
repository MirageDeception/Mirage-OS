import json
import os
import boto3

sns = boto3.client('sns')

def handler(event, context):
    print("Received event: " + json.dumps(event))
    
    topic_arn = os.environ.get('SNS_TOPIC_ARN')
    
    message = f"🚨 DECEPTION ALERT 🚨\n\nEvent: {json.dumps(event, indent=2)}"
    
    try:
        sns.publish(
            TopicArn=topic_arn,
            Subject="Mirage Deception Alert",
            Message=message
        )
    except Exception as e:
        print(f"Error publishing to SNS: {e}")
        
    return {"statusCode": 200, "body": "Alert processed"}
